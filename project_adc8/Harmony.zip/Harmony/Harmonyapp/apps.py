from django.apps import AppConfig


class HarmonyappConfig(AppConfig):
    name = 'Harmonyapp'
